package DesignPrinciplesAndPatterns.FactoryMethodPatternExample;

public class WordDocument implements Document {

    public void open() {
        System.out.println("Opening Word Document...");
    }
    
}
